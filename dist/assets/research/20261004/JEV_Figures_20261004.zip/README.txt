JEV RESEARCH | Figures updated 4 October 2026
Five complete figures and five separate mechanism panels (a).
Native PDF/SVG and 600 dpi PNG.
Figure 2a connectors, Figure 3a Local argmin overlap and Figure 4a confidence branch origins are corrected.
Quantitative data are unchanged.
